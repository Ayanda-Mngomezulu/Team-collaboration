package com.example.compassapp

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class MainActivity_Wallet : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_wallet)
        // Assume display of wallet summary
    }
}