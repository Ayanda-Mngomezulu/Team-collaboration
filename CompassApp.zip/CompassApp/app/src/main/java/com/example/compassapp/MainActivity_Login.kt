package com.example.compassapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity_Login : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_login)

        val btnLogin = findViewById<Button>(R.id.btnLoginNow)
        val txtSignup = findViewById<TextView>(R.id.txtSignup)

        btnLogin.setOnClickListener {
            // Navigate to Wallet screen after login
            startActivity(Intent(this, MainActivity_Wallet::class.java))
        }

        txtSignup.setOnClickListener {
            // Navigate to Register screen
            startActivity(Intent(this, MainActivity_register::class.java))
        }
    }
}
