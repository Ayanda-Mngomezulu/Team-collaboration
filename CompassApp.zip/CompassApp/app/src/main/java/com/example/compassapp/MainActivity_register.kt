package com.example.compassapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity_register : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_register)

        val btnRegister = findViewById<Button>(R.id.btnRegister)
        val btnCancel = findViewById<Button>(R.id.btnCancel)

        btnRegister.setOnClickListener {
            // After register, navigate to Wallet
            startActivity(Intent(this, MainActivity_Wallet::class.java))
        }

        btnCancel.setOnClickListener {
            // Cancel goes back to Landing
            startActivity(Intent(this, MainActivity_Landingpag::class.java))
        }
    }
}