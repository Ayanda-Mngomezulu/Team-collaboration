package com.example.login;

public class Transaction {
    String title, method, amount;
    int iconResId;

    public Transaction(String title, String method, String amount, int iconResId) {
        this.title = title;
        this.method = method;
        this.amount = amount;
        this.iconResId = iconResId;
    }
}


