package com.example.personalbudgetingapp

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.login.Transaction
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivity : AppCompatActivity() {
    private var recyclerView: RecyclerView? = null
    private var adapter: TransactionAdapter? = null
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        recyclerView = findViewById<RecyclerView>(R.id.transactionRecyclerView)
        recyclerView.setLayoutManager(LinearLayoutManager(this))
        val transactions: MutableList<Transaction> = ArrayList<Transaction>()
        transactions.add(Transaction("Investment Profit", "Cash", "R300", R.drawable.ic_investment))
        transactions.add(Transaction("Bought Lunch", "Cash", "-R20", R.drawable.ic_lunch))
        transactions.add(Transaction("Other", "Cash", "R200", R.drawable.ic_other))
        transactions.add(Transaction("Petrol", "Cash", "-R300", R.drawable.ic_petrol))
        adapter = TransactionAdapter(transactions)
        recyclerView.setAdapter(adapter)
        val bottomNav = findViewById<BottomNavigationView>(R.id.bottom_nav)
        bottomNav.setOnNavigationItemSelectedListener { item: MenuItem? -> true }
    }
}
